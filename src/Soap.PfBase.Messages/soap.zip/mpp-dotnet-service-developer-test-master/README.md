# MyPinPad.WebService

ASP.NET Core 3 web application test.

## Instructions

 - Create an ASP.NET Core 3 Web API project named `MyPinPad.WebService.Host` in the solution
 - Create an implementation of `IDataService` and expose according to the schema described below
 - Within a test project create unit tests for the `IDataService` implementation

 Optional: 
 
 - Create integration tests for the Web API
 - Add a custom exception handler that outputs a friendly message on error
 - Configure a logging provider that logs to a file - ideally the filter level should be configurable via an
   `appSettings.json` configuration file

Additional notes:

 - Third party packages on nuget.org can be used where required
  - Suggested packages: Serilog for logging, XUnit for tests
 - The host should be minimal containing only what is absolutely necessary
 - Assume production level/shipping code throughout


# Web API Schema

## Conventions

### Status Codes

The following table lists the status codes used by the API across all resources:

Code        | When
-----------:|-----
**400**     | The request has a malformed syntax.
**404**     | The identified resource could not be found.
**500**     | An unexpected condition was encountered and the request could not be fulfilled.


### Serialization

All request and response bodies are serialized using JavaScript Object Notation (JSON). All requests should include
the header: `Content-Type: application/json`.

This table describes the JSON type and encoding used to serialize various model types:

Model Type        | JSON Type    | Encoding
-----------------:|-------------:|---------
`byte[]`          | `string`     | base-64
`integer`         | `number`     |


## Resources

### `/wait/{wait-period}`

#### URL Items

Item                    | Type                  | Required
-----------------------:|-----------------------|-----------------------
`wait-period`           | `{wait-period}`       | yes


#### GET

Waits the specified period then returns a `204` response.

`{wait-period}` has the following structure:

    An integer followed by one of `ms`, `s` or `m` for milliseconds, seconds and minutes respectively.

Examples:

    10ms  -  10 milliseconds
    14s   -  14 seconds

##### Response on success

Item          | Value
-------------:|------
Status Code   | 204


### `/md5-digest`

#### POST

Returns the MD5 digest of the supplied bytes.

##### Request Items

Item          | Value
-------------:|------
Body          | `{md5-digest-request-body}`

##### Response Items on success

Item          | Value
-------------:|------
Status Code   | 200
Body          | `{md5-digest-response-body}`

##### `md5-digest-request-body`

```javascript
{
  // The message from which to create the MD5 digest
  "Message": required: yes, type:  byte[], length: 16..256;

  // An optional salt value to be applied to the MD5 operation
  "Salt": required: no, type: byte[], length: 16..256;
}
```

##### `md5-digest-response-body`

```javascript
{
  // The resulting MD5 digest
  "Digest": presence: always, type: byte[], length: 16;
}
```
