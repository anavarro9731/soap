﻿using System;
using System.Threading.Tasks;

namespace MyPinPad.WebService
{
    /// <summary>
    /// Interface for the Web Service data service.
    /// </summary>
    public interface IDataService
    {
        /// <summary>
        /// Waits the given wait period.
        /// </summary>
        /// <param name="waitPeriod">The period of time to wait before completing.</param>
        Task Wait(TimeSpan waitPeriod);

        /// <summary>
        /// Generates an MD5 of the provided <paramref name="message"/>, applying the <paramref name="salt"/> value if
        /// provided.
        /// </summary>
        /// <param name="message">The message to hash.</param>
        /// <param name="salt">The optional salt value.</param>
        Task GenerateMd5Digest(byte[] message, byte[] salt = null);
    }
}